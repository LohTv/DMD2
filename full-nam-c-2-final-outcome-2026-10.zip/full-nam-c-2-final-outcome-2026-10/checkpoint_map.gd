extends Node2D
const Data = preload("res://scripts/route_data.gd")

enum State { READY, WAITING, TRAVELLING, FINISHED }
const MAP_ORIGIN = Vector2(0, 0)
const START_TIME = 480.0
const DEADLINE = 570.0
const GOAL = 6
const IDLE_SPEED = 0.12
const TRAVEL_SPEED = 4.0

var state = State.READY
var game_time = START_TIME
var tokens = 10
var current_stop = 0
var selected_stop = -1
var hovered_stop = -1
var active_route = -1
var departure_time = 0.0
var arrival_time = 0.0
var routes: Array = Data.create_routes()

@onready var clock_label: Label = $Clock
@onready var money_label: Label = $Money
@onready var status_label: Label = $Status
@onready var options: VBoxContainer = $Options
@onready var connections_label: Label = $Connections
@onready var status_label_2: Label = $Status2

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		var mouse_position = get_global_transform_with_canvas().affine_inverse() * event.position
		for index in range(Data.STOPS.size()):
			var stop_position: Vector2 = MAP_ORIGIN + Data.STOPS[index].pos
			if mouse_position.distance_to(stop_position) <= 24.0:
				select_stop(index)
				get_viewport().set_input_as_handled()
				return
	#elif event is InputEventMouseButton and event.not_pressed:
		#var mouse_position = get_global_transform_with_canvas().affine_inverse() * event.position
		#for index in range(Data.STOPS.size()):
			#var stop_position: Vector2 = MAP_ORIGIN + Data.STOPS[index].pos
			#if mouse_position.distance_to(stop_position) <= 24.0:
				#hover_stop(index)
				#return

func _draw() -> void:
	for index in range(routes.size()):
		var route: Dictionary = routes[index]
		if route.mode == "walk" and route.from > route.to:
			continue
		var colour = Color("cc3333") if route.mode == "horse" else Color("222222")
		if route.mode == "walk":
			colour = Color("777777")
		colour.a = 0.00
		draw_line(MAP_ORIGIN + Data.STOPS[route.from].pos, MAP_ORIGIN + Data.STOPS[route.to].pos, colour, 4.0, true)
	if state == State.TRAVELLING:
		var route: Dictionary = routes[active_route]
		var colour = Color("cc3333") if route.mode == "horse" else Color("222222")
		if route.mode == "walk":
			colour = Color("777777")
		colour.a = travel_progress()
		draw_line(MAP_ORIGIN + Data.STOPS[route.from].pos, MAP_ORIGIN + Data.STOPS[route.to].pos, colour, 6.0, true)
	for index in range(Data.STOPS.size()):
		var stop: Dictionary = Data.STOPS[index]
		var point: Vector2 = MAP_ORIGIN + stop.pos
		if index == selected_stop:
			draw_arc(point, 20.0, 0.0, TAU, 32, Color("287fa3"), 2.0, true)
		continue
		if stop.rail:
			draw_rect(Rect2(point - Vector2(12, 12), Vector2(24, 24)), Color.WHITE)
			draw_rect(Rect2(point - Vector2(12, 12), Vector2(24, 24)), Color("222222"), false, 3.0)
		else:
			draw_circle(point, 12.0, Color.WHITE)
			draw_arc(point, 12.0, 0.0, TAU, 32, Color("cc3333"), 3.0, true)
		draw_string(ThemeDB.fallback_font, point + Vector2(-6, -22), str(index), HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color("222222"))
		
	draw_arc(player_position(), 20.0, 0.0, TAU, 32, Color("d59a00"), 4.0, true)
	draw_circle(player_position(), 4.0, Color("d59a00"))
	
func time_text(minutes: float) -> String:
	var whole_minutes = floori(minutes + 0.000001)
	return "%02d:%02d" % [whole_minutes / 60, whole_minutes % 60]


func next_departure(route: Dictionary, at_time: float = -1):
	var now = game_time if at_time < 0.0 else at_time
	if route.mode == "walk":
		return now
	var services_passed = maxi(0, ceili((now - route.first) / route.interval))
	return route.first + services_passed * route.interval


func select_stop(stop_index: int):
	if state == State.WAITING:
		cancel_wait()
		return
	if state != State.READY:
		return
	selected_stop = -1 if stop_index == current_stop else stop_index
	rebuild_options()
	update_display()

func hover_stop(stop_index: int):
	hovered_stop = stop_index
	update_display()
	
func available_routes():
	var result = []
	if state != State.READY:
		return result
	for index in range(routes.size()):
		var route = routes[index]
		if route.from != current_stop:
			continue
		if selected_stop != -1 and route.to != selected_stop:
			continue
		result.append(index)
	return result


func rebuild_options() -> void:
	for child in options.get_children():
		options.remove_child(child)
		child.queue_free()
	for index in available_routes():
		var button = Button.new()
		button.custom_minimum_size = Vector2(320, 70)
		button.focus_mode = Control.FOCUS_NONE
		button.set_meta("route_index", index)
		button.pressed.connect(choose_route.bind(index))
		options.add_child(button)


func choose_route(route_index: int) -> void:
	if state != State.READY:
		return
	var route = routes[route_index]
	if route.from != current_stop or route.cost > tokens:
		return
	active_route = route_index
	departure_time = next_departure(route)
	arrival_time = departure_time + route.duration
	state = State.WAITING
	if departure_time <= game_time:
		board()
	rebuild_options()
	update_display()


func board() -> void:
	if state != State.WAITING:
		return
	tokens -= int(routes[active_route].cost)
	state = State.TRAVELLING


func cancel_wait() -> void:
	if state != State.WAITING:
		return
	state = State.READY
	active_route = -1
	selected_stop = -1
	rebuild_options()
	update_display()
	
	
func tick_clock(delta: float):
	if state == State.FINISHED:return
	var speed = IDLE_SPEED if state == State.READY else TRAVEL_SPEED
	var next_time = game_time + delta * speed
	if state == State.WAITING:
		game_time = minf(next_time, departure_time)
		if game_time >= departure_time:
			board()
	elif state == State.TRAVELLING:
		game_time = minf(next_time, arrival_time)
		if game_time >= arrival_time:
			arrive()
	else: game_time = next_time
	
	
func arrive():
	if state != State.TRAVELLING:
		return
	current_stop = int(routes[active_route].to)
	active_route = -1
	selected_stop = -1
	state = State.FINISHED if current_stop == GOAL else State.READY
	rebuild_options()
	
	
func travel_progress():
	if state != State.TRAVELLING:
		return 0.0
	return clampf((game_time - departure_time) / (arrival_time - departure_time), 0.0, 1.0)
	

func player_position():
	if state != State.TRAVELLING:
		return MAP_ORIGIN + Data.STOPS[current_stop].pos
	var route = routes[active_route]
	var start: Vector2 = Data.STOPS[route.from].pos
	var finish: Vector2 = Data.STOPS[route.to].pos
	return MAP_ORIGIN + start.lerp(finish, travel_progress())


func update_display() -> void:
	var clock_str = "Time: " + str(time_text(game_time)) 
	var current_stop_name = Data.STOPS[current_stop].name
	clock_label.text = clock_str
	money_label.text = "%d Tokens" % tokens
	status_label.text = "Stop: " + current_stop_name
	status_label_2.text = "Choose below, or click a map stop"
	if state == State.READY and selected_stop != -1:
		var to_stop_name = Data.STOPS[selected_stop].name
		status_label_2.text = "To " + to_stop_name
		if available_routes().is_empty():
			status_label_2.text += " | No direct route"
	elif state == State.READY and selected_stop != -1:
		status_label_2.text = "Choose below, or click a map stop"
	elif state == State.WAITING:
		var s1 = "Waiting until %s" % time_text(departure_time)
		status_label_2.text = s1 +  " \nClick stop " + current_stop_name + " to cancel"
	elif state == State.TRAVELLING:
		status_label_2.text = "%s to %d | Arrive %s" % [routes[active_route].mode.capitalize(), routes[active_route].to, time_text(arrival_time)]
	elif state == State.FINISHED:
		status_label_2.text = "Arrived on time" if game_time <= DEADLINE else "Arrived too late"

	var preview_stop = -1
	var preview_time = INF
	for button in options.get_children():
		var route: Dictionary = routes[int(button.get_meta("route_index"))]
		var leaves = next_departure(route)
		button.text = "%s > %d | %d tokens\nDep %s | Arr %s" % [route.mode.capitalize(), route.to, route.cost, time_text(leaves), time_text(leaves + route.duration)]
		button.disabled = route.cost > tokens
		if button.disabled:
			button.text += "\nToo expensive"
		if selected_stop != -1:
			preview_stop = selected_stop
			preview_time = minf(preview_time, leaves + route.duration)
	if state == State.WAITING or state == State.TRAVELLING:
		preview_stop = int(routes[active_route].to)
		preview_time = arrival_time
	connections_label.text = connection_note(preview_stop, preview_time) if preview_stop >= 0 else ""
	queue_redraw()


func connection_note(stop_index: int, at_time: float) -> String:
	if stop_index == GOAL:
		return ""
	var lines: Array[String] = ["Next from %d (after %s):" % [stop_index, time_text(at_time)]]
	for route in routes:
		if route.from != stop_index:
			continue
		var leaves = next_departure(route, at_time)
		lines.append("%s > %d: %s - %s, %d tokens" % [route.mode.capitalize(), route.to, time_text(leaves), time_text(leaves + route.duration), route.cost])
	return "\n".join(lines)


func _ready() -> void:
	rebuild_options()
	update_display()


func _process(delta: float) -> void:
	tick_clock(delta)
	update_display()
