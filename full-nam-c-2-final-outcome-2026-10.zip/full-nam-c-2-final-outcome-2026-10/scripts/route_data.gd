extends RefCounted

const STOPS: Array[Dictionary] = [
	{"pos": Vector2(80, 509), "rail": false, "name": "Potsdam"}, {"pos": Vector2(208, 478), "rail": false, "name": "Glienicke"}, {"pos": Vector2(484.0, 444), "rail": false, "name": "Zehlendorf"}, 
	{"pos": Vector2(560.0, 421.0), "rail": false, "name": "Steglitz"}, {"pos": Vector2(688.0, 373.0), "rail": false, "name": ""}, {"pos": Vector2(782.0, 321.0), "rail": false, "name": "Potsdamer Tor"}, 
	{"pos": Vector2(824.0, 259.0), "rail": false, "name": ""}, 
	
	{"pos": Vector2(102.0, 551), "rail": true, "name": "Potsdam Station"}, {"pos": Vector2(577.0, 453.0), "rail": true, "name": "Zehlendorf Station"}, {"pos": Vector2(828.0, 288.0), "rail": true, "name": "Potsdamer Bahnhof"}
]

static func leg(from_stop: int, to_stop: int, mode: String,
		first: float, interval: float, duration: float, cost: int) -> Dictionary:
	return {
		"from": from_stop, "to": to_stop, "mode": mode,
		"first": first, "interval": interval, "duration": duration, "cost": cost,
	}
	
static func create_routes():
	return [
		leg(0, 1, "horse", 485, 20, 10, 2),
		leg(1, 2, "horse", 485, 20, 10, 2),
		leg(2, 3, "horse", 485, 20, 10, 2),
		leg(3, 4, "horse", 485, 20, 10, 2),
		leg(4, 5, "horse", 485, 20, 10, 2),
		leg(5, 6, "horse", 485, 20, 10, 2),
		leg(7, 8, "train", 485, 20, 10, 3),
		leg(8, 9, "train", 485, 20, 10, 3),
		leg(0, 7, "walk", 0, 0, 5, 0),
		leg(7, 0, "walk", 0, 0, 5, 0),
		leg(3, 8, "walk", 0, 0, 5, 0),
		leg(8, 3, "walk", 0, 0, 5, 0),
		leg(6, 9, "walk", 0, 0, 5, 0),
		leg(9, 6, "walk", 0, 0, 5, 0),
	]
